#include <ft2build.h>
#include FT_FREETYPE_H

int main(void) {
  FT_Long has_color = FT_HAS_COLOR(((FT_Face)NULL));
  return 0;
}
