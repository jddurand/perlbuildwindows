### Docker container infrastructure for JPEG XL

This directory contains the requirements to build a docker image for the
JPEG XL project builder.

Docker images need to be created and upload manually. See ./build.sh for
details.
