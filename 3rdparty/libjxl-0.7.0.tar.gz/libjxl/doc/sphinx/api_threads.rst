Multi-threaded Encoder/Decoder
==============================

.. doxygengroup:: libjxl_threads
   :members:
   :private-members:
