Butteraugli API - ``jxl/butteraugli.h``
=======================================

.. doxygengroup:: libjxl_butteraugli
   :members:
   :private-members:
