Common API concepts
===================

.. doxygengroup:: libjxl_common
   :members:
   :private-members:
