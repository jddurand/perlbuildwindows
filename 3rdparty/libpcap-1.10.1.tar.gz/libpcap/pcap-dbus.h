pcap_t *dbus_create(const char *, char *, int *);
int dbus_findalldevs(pcap_if_list_t *devlistp, char *errbuf);
